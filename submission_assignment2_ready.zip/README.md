# MLOps Assignment 2: Cats vs Dogs

This repository contains a complete submission-ready implementation for Assignment 2, excluding only the demo video.

Primary report: `FINAL_SUBMISSION_REPORT.md`

## 1. Prerequisites

1. Python 3.11+
2. Docker Desktop (for container run and deployment flow)
3. Git (optional for cloning)

## 2. Reproduce Training and Artifacts (M1)

Run from repository root:

```bash
pip install -r requirements-dev.txt
python -m dvc repro
```

Expected outputs:

1. `models/cnn_latest.pt`
2. `artifacts/loss_curves.png`
3. `artifacts/confusion_matrix.png`

Notes:

1. If Kaggle credentials are unavailable, the pipeline automatically uses fallback synthetic images so execution still works on a new machine.
2. MLflow logs runs, parameters, metrics, and artifacts to `mlruns/`.

## 3. Run Unit Tests (M3)

```bash
pytest tests -q
```

Expected result: all tests pass.

## 4. Run API Without Docker (M2)

Terminal 1:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Terminal 2:

```bash
python scripts/smoke_test.py --url http://localhost:8000
```

Expected result: `ALL TESTS PASSED`.

## 5. Run API With Docker Compose (M2 and M4)

```bash
docker compose up --build -d
python scripts/smoke_test.py --url http://localhost:8000
docker compose down
```

The Compose service mounts `./models` into the container and uses `models/cnn_latest.pt`.

## 6. Monitoring and Post-Deployment Tracking (M5)

1. API exposes metrics at `/metrics`.
2. Prometheus and Grafana compose file: `monitoring/docker-compose.monitoring.yml`.
3. Post-deployment simulation:

```bash
python scripts/simulate_requests.py --url http://localhost:8000 --num-requests 20
```

Outputs:

1. `artifacts/post_deploy_requests.csv`
2. `artifacts/post_deploy_summary.json`

## 7. CI/CD Workflow (M3 and M4)

Workflow file: `.github/workflows/ci-cd.yml`

On pull request to main:

1. Install dependencies
2. Run unit tests
3. Build Docker image

On push to main:

1. Run tests
2. Build and push image to GHCR
3. Deploy with Docker Compose
4. Wait for health endpoint
5. Run smoke tests

## 8. Create Final Submission ZIP (< 10 MB)

Use the packaging script to generate a clean, portable archive:

```bash
python scripts/create_submission_zip.py
```

Generated file:

1. `submission_assignment2_ready.zip`

The script excludes non-required heavy folders (`.venv`, `.git`, `.dvc/cache`, `data`, `mlruns`, caches, old zip files) and enforces a 10 MB size limit.

## 9. What To Submit

1. `submission_assignment2_ready.zip`
2. Demo video under 5 minutes (to be added separately)
