import fnmatch
import os
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ZIP = ROOT / "submission_assignment2_ready.zip"
MAX_BYTES = 10 * 1024 * 1024

INCLUDE_PATHS = [
    "app",
    "src",
    "tests",
    "scripts",
    "k8s",
    "monitoring",
    ".github/workflows",
    "models",
    "artifacts",
    "Dockerfile",
    "docker-compose.yml",
    "dvc.yaml",
    "dvc.lock",
    "requirements.txt",
    "requirements-dev.txt",
    "README.md",
    "FINAL_SUBMISSION_REPORT.md",
    ".gitignore",
    ".dockerignore",
    ".gitattributes",
    ".dvc/.gitignore",
]

EXCLUDE_PATTERNS = [
    "*.zip",
    "__pycache__/*",
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".pytest_cache/*",
    ".venv/*",
    ".git/*",
    ".dvc/cache/*",
    ".dvc/tmp/*",
    "data/*",
    "mlruns/*",
    ".vscode/*",
]


def is_excluded(rel_path: str) -> bool:
    normalized = rel_path.replace("\\", "/")
    for pattern in EXCLUDE_PATTERNS:
        if fnmatch.fnmatch(normalized, pattern):
            return True
    return False


def collect_files() -> list[Path]:
    files: list[Path] = []
    for rel in INCLUDE_PATHS:
        target = ROOT / rel
        if not target.exists():
            continue
        if target.is_file():
            rel_path = target.relative_to(ROOT)
            if not is_excluded(str(rel_path)):
                files.append(target)
            continue

        for path in target.rglob("*"):
            if not path.is_file():
                continue
            rel_path = path.relative_to(ROOT)
            if is_excluded(str(rel_path)):
                continue
            files.append(path)

    unique_files = sorted(set(files), key=lambda p: str(p).lower())
    return unique_files


def main() -> None:
    files = collect_files()

    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()

    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for file_path in files:
            arcname = file_path.relative_to(ROOT).as_posix()
            zf.write(file_path, arcname=arcname)

    size = OUTPUT_ZIP.stat().st_size

    print(f"Created: {OUTPUT_ZIP.name}")
    print(f"Files included: {len(files)}")
    print(f"Archive size: {size / (1024 * 1024):.2f} MB")

    if size > MAX_BYTES:
        raise SystemExit(
            f"ERROR: Archive exceeds 10 MB limit ({size / (1024 * 1024):.2f} MB)."
        )

    print("Archive is within 10 MB limit.")


if __name__ == "__main__":
    main()
