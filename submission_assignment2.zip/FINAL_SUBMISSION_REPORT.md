# Assignment 2 Final Submission Report

This repository implements the required end-to-end MLOps workflow for the Cats vs Dogs binary image classification use case from Assignment 2. The demo video is not included here and can be recorded separately.

## Requirement Checklist

### M1. Model Development and Experiment Tracking
1. Git-based project structure and DVC pipeline for preprocessing, training, and evaluation are included.
2. A baseline CNN model is implemented and saved as `models/cnn_latest.pt`.
3. MLflow logging is integrated for parameters, metrics, and artifacts.

Evidence:
1. `dvc.yaml`
2. `dvc.lock`
3. `src/model.py`
4. `src/train.py`
5. `src/evaluate.py`
6. `models/cnn_latest.pt`

### M2. Model Packaging and Containerization
1. FastAPI inference service exposes `/health` and `/predict`.
2. Dependencies are pinned in `requirements.txt` and `requirements-dev.txt`.
3. Docker packaging is provided through `Dockerfile` and `docker-compose.yml`.

Evidence:
1. `app/main.py`
2. `app/utils.py`
3. `requirements.txt`
4. `requirements-dev.txt`
5. `Dockerfile`
6. `docker-compose.yml`

### M3. CI Pipeline for Build, Test, and Image Creation
1. Unit tests cover one preprocessing function and one inference/model utility path.
2. GitHub Actions installs dependencies, runs pytest, and builds the Docker image.
3. The workflow publishes the image to GitHub Container Registry.

Evidence:
1. `tests/test_preprocessing.py`
2. `tests/test_inference.py`
3. `.github/workflows/ci-cd.yml`

### M4. CD Pipeline and Deployment
1. Docker Compose is used as the deployment target.
2. The workflow updates the running service on `main` branch pushes.
3. Post-deployment smoke testing is included.

Evidence:
1. `docker-compose.yml`
2. `.github/workflows/ci-cd.yml`
3. `scripts/smoke_test.py`

### M5. Monitoring, Logs, and Post-Deployment Tracking
1. Request logging and basic latency/request metrics are implemented in the API.
2. A simulation script is included to collect post-deployment prediction results.

Evidence:
1. `app/main.py`
2. `monitoring/prometheus.yml`
3. `scripts/simulate_requests.py`

## Required Output Images

### Training Loss Curve
![Training Loss Curve](artifacts/loss_curves.png)

### Confusion Matrix
![Confusion Matrix](artifacts/confusion_matrix.png)

## Deliverables Included

1. Source code
2. DVC configuration
3. CI/CD workflow
4. Docker and deployment files
5. Trained model artifact
6. Test suite
7. Final submission report

## Pending Item

1. Screen recording under 5 minutes can be recorded separately.
