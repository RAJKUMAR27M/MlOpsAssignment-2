# Assignment 2 Submission (MLOps - Cats vs Dogs)

Primary submission document:

1. `FINAL_SUBMISSION_REPORT.md`

## Extract and Run from Submitted ZIP (Different Machine)

1. Copy `submission_assignment2.zip` to the target machine.
2. Extract it to a folder, for example `MLOPS-2`.
3. Open terminal in the extracted folder root.

### Fast path (Docker)

1. Install Docker Desktop (or Docker Engine + Compose plugin).
2. Run:

```bash
docker compose up --build -d
```

3. Verify health endpoint:

```bash
curl http://localhost:8000/health
```

4. Run smoke tests:

```bash
python scripts/smoke_test.py --url http://localhost:8000
```

5. Expected result: `ALL TESTS PASSED`.

### Python path (without Docker)

1. Install Python 3.11 or newer.
2. Install dependencies:

```bash
pip install -r requirements-dev.txt
```

3. Run unit tests:

```bash
pytest tests -q
```

4. Start API:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

5. In another terminal, run smoke tests:

```bash
python scripts/smoke_test.py --url http://localhost:8000
```

6. Expected result: `ALL TESTS PASSED`.

## Quick Reproducibility Guide

This project was verified with local unit tests and smoke tests.

### Option A: Run with Docker Compose (recommended)

1. Install Docker Desktop.
2. Open terminal at project root.
3. Run:

```bash
docker compose up --build -d
```

4. Verify service:

```bash
curl http://localhost:8000/health
```

5. Run smoke tests:

```bash
python scripts/smoke_test.py --url http://localhost:8000
```

### Option B: Run directly with Python

1. Use Python 3.11+.
2. Install dependencies:

```bash
pip install -r requirements-dev.txt
```

3. Run unit tests:

```bash
pytest tests -q
```

4. Start API:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

5. In another terminal, run smoke tests:

```bash
python scripts/smoke_test.py --url http://localhost:8000
```

## DVC Pipeline

DVC stages are defined in `dvc.yaml` for preprocess, train, and evaluate.

Run all stages:

```bash
dvc repro
```

## Notes

1. The report contains PDF-aligned checklist and evidence mapping.
2. The demo video (under 5 minutes) should be submitted separately.
